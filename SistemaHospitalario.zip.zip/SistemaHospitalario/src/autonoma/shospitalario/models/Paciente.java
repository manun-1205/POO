
package autonoma.shospitalario.models;

/**
 *
 * @author Manuel
 */
public class Paciente extends Persona{
    
    //atributos
    private String historialMedico;
    
    //constructor
    
    public Paciente(String nombre, int edad, int cedula, String historialMedico){
        super(nombre, edad, cedula);
        this.historialMedico = historialMedico;
    }
    
    //setters and getters

    public String getHistorialMedico() {
        return historialMedico;
    }

    public void setHistorialMedico(String historialMedico) {
        this.historialMedico = historialMedico;
    }
    
    //metodos
    
    
    @Override
    public String mostrarInformacion(){
    return super.mostrarInformacion() + ", historial medico: " + this.historialMedico;
    } 
    
    
    
}
