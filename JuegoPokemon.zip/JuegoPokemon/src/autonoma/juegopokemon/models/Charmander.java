/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.juegopokemon.models;

/**
 *
 * @author Manuel
 */
public class Charmander extends Pokemon implements PokemonFuego{

    public Charmander(int numPokedex, String nombre, Double peso, String temporada) {
        super(numPokedex, nombre, peso, temporada);
    }

    @Override
    public String atacarArañazo() {
        return "soy "+this.getNombre()+" y estoy usando arañazo";
    }

    @Override
    public String atacarMordizco() {
       return "soy "+this.getNombre()+" y estoy usando Mordizco";}

    @Override
    public String atacatPunioFuego() {
        return "soy "+this.getNombre()+" y estoy usando Puño de Fuego";}

    @Override
    public String atacarAscuas() {
        return "soy "+this.getNombre()+" y estoy usando Ascuas";
    }

    @Override
    public String atacarLanzallamas() {
        return "soy "+this.getNombre()+" y estoy usando Lanza Llamas";
    }
    
}
