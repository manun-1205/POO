/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.juegopokemon.models;

/**
 *
 * @author Manuel
 */
public class Bulbasur extends Pokemon implements PokemonPlanta {

    public Bulbasur(int numPokedex, String nombre, Double peso, String temporada) {
        super(numPokedex, nombre, peso, temporada);
    }

    @Override
    public String atacarArañazo() {
        return "soy "+this.getNombre()+" y estoy usando arañazo";
    }

    @Override
    public String atacarMordizco() {
        return "soy "+this.getNombre()+" y estoy usando Mordizco";
    }

    @Override
    public String atacatParalizar() {
        return "soy "+this.getNombre()+" y estoy usando Paralizar";
    }

    @Override
    public String atacarDrenaje() {
        return "soy "+this.getNombre()+" y estoy usando Drenaje";
    }
        
    @Override
    public String atacarHojaAfilada() {
        return "soy "+this.getNombre()+" y estoy usando Hoja Afilada";
    }

    @Override
    public String atacarLatigoCepta() {
        return "soy "+this.getNombre()+" y estoy usando Latigo cepa";
    }
    
}
