/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.shospitalario.main;

import autonoma.shospitalario.models.Farmacia;
import autonoma.shospitalario.models.Hospital;
import autonoma.shospitalario.views.VentanaSeleccion;

/**
 *
 * @author Manuel
 */
public class HospitalApp {
    
    public static void main(String args[]){
        Hospital hospital = new Hospital ("Gran Soledo","carrera 27b #11a - 18");
        Farmacia farmacia = new Farmacia();
        VentanaSeleccion ventana = new VentanaSeleccion(hospital, farmacia);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    }
    
}
