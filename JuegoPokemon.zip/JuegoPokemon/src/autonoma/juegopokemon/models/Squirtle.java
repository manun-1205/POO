/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.juegopokemon.models;


/**
 *
 * @author Manuel
 */
public class Squirtle extends Pokemon implements PokemonAgua {

    public Squirtle(int numPokedex, String nombre, Double peso, String temporada) {
        super(numPokedex, nombre, peso, temporada);
    }

    @Override
    public String atacarArañazo() {
        return "soy "+this.getNombre()+" y estoy usando arañazo";
    }

    @Override
    public String atacarMordizco() {
        return "soy "+this.getNombre()+" y estoy usando Mordizco";
    }

    @Override
    public String atacatHidroBomba() {
        return "soy "+this.getNombre()+" y estoy usando HidroBomba";
    }

    @Override
    public String atacarPistolaAgua() {
        return "soy "+this.getNombre()+" y estoy usando Pistola de Agua";}

    @Override
    public String atacarBurbuja() {
        return "soy "+this.getNombre()+" y estoy usando Burbuja";}

    @Override
    public String atacarHidroPulso() {
        return "soy "+this.getNombre()+" y estoy usando HidroPulso";}
    
}
