
package autonoma.shospitalario.models;

/**
 *
 * @author Manuel
 */
public class Medico extends Persona{
    
    //atributos
    
    private String especialidad;
    private int identificacion;
    
    //constructor

    public Medico(String nombre, int edad, int cedula, String especialidad, int identificacion) {
        super(nombre, edad, cedula);
        this.especialidad = especialidad;
        this.identificacion = identificacion;
    }
    
    //setters and getters

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(int identificacion) {
        this.identificacion = identificacion;
    }

    
    @Override
    public String mostrarInformacion(){
    return super.mostrarInformacion() + ", especialidad: " + this.especialidad + ", numero de identificacion " 
            + this.identificacion;
    }
    
}
