/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package autonoma.juegopokemon.models;

/**
 *
 * @author Manuel
 */
public interface PokemonElectrico {
    
    public abstract String atacatImpactoTrueno();
    public abstract String atacarRayo();
    public abstract String punioTrueno();
    public abstract String rayoCarga();
    
}
