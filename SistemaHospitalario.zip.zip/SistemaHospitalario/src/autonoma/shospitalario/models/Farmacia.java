/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.shospitalario.models;

import java.util.ArrayList;

/**
 *
 * @author Manuel
 */
public class Farmacia{
    
    
    private ArrayList<MedicamentoGenerico>medicamentosGenericos;
    private ArrayList<MedicamentoMarca>medicamentosDeMarca;

    public Farmacia() {
 
        this.medicamentosDeMarca = new ArrayList();
        this.medicamentosGenericos = new ArrayList();
    }
    
    public boolean agregarMedicamentoGenerico(MedicamentoGenerico  m){
        return this.medicamentosGenericos.add(m);
    }
    
    public boolean agregarMedicamentoMarca(MedicamentoMarca  m){
        return this.medicamentosDeMarca.add(m);
    }
    
    public MedicamentoGenerico buscarMedicamentoGenerico(String nombre){
        for(MedicamentoGenerico m : medicamentosGenericos){
            if(m.getNombre().equals(nombre))
                return m;
        }
        return null;
    }
    
    public MedicamentoMarca buscarMedicamentoMarca(String nombre){
        for(MedicamentoMarca m : medicamentosDeMarca){
            if(m.getNombre().equals(nombre))
                return m;
        }
        return null;
    }
    
    private int buscarIndiceMedicamentoGenerico(String nombre){
        for(int i=0; i < this.medicamentosGenericos.size();i++){
            MedicamentoGenerico m = this.medicamentosGenericos.get(i);
            if(m.getNombre().equals(nombre)){
                return i;
            }
        }
        return -1;
    }
    
    private int buscarIndiceMedicamentoMarca(String nombre){
        for(int i=0; i < this.medicamentosDeMarca.size();i++){
            MedicamentoMarca m = this.medicamentosDeMarca.get(i);
            if(m.getNombre().equals(nombre)){
                return i;
            }
        }
        return -1;
    }
    
    public boolean eliminarMedicamentoGenerico(String nombre){
        int index = this.buscarIndiceMedicamentoGenerico(nombre);
        if(index > 0){
            this.medicamentosGenericos.remove(index);
        }
        return false;
    }
    
    public boolean eliminarMedicamentoMarca(String nombre){
        int index = this.buscarIndiceMedicamentoMarca(nombre);
        if(index > 0){
            this.medicamentosDeMarca.remove(index);
        }
        return false;
    }
    
    public boolean actualizarMedicamentoGenerico(String nombre, MedicamentoGenerico medicamento){
        int index = this.buscarIndiceMedicamentoGenerico(nombre);
        if(index > 0){
            this.medicamentosGenericos.set(index, medicamento);
        }
        return false;
    }
    
    public boolean actualizarMedicamentoMarca(String nombre, MedicamentoMarca medicamento){
        int index = this.buscarIndiceMedicamentoMarca(nombre);
        if(index > 0){
            this.medicamentosDeMarca.set(index, medicamento);
        }
        return false;
    }
    
    public ArrayList<MedicamentoGenerico> getMedicamentosGenericos(){
        return this.medicamentosGenericos;
    }
    
    public ArrayList<MedicamentoMarca> getMedicamentosDeMarca(){
        return this.medicamentosDeMarca;
    }
    
    
    
    
    
}