/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.shospitalario.models;

/**
 *
 * @author Manuel
 */
public abstract class Medicamento {
    private String nombre;          // Atributo: nombre del medicamento
    private String descripcion;     // Atributo: descripción del medicamento
    private double costo;           // Atributo: costo del medicamento
    private double precioVenta;     // Atributo: precio de venta

    public Medicamento(String nombre, String descripcion, double costo, double precioVenta) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.costo = costo;
        this.precioVenta = precioVenta; // Calculo automático
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public void setPrecioVenta(double precioVenta) {
        this.precioVenta = precioVenta;
    }
    
    

    

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public double getCosto() {
        return costo;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }
}