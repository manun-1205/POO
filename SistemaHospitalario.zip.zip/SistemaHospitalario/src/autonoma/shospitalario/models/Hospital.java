
package autonoma.shospitalario.models;

import java.util.ArrayList;

/**
 *
 * @author Manuel
 */
public class Hospital {
    //atibutos
    
    private String nombre;
    private String direccion;
    private ArrayList<Medico> medicos;
    private ArrayList<Paciente>pacientes;
    private ArrayList<Cita>citas;
    
    //constructor
    
    public Hospital(String nombre, String direccion){
        this.medicos = new ArrayList();
        this.pacientes = new ArrayList();
        this.citas = new ArrayList();
        this.nombre = nombre;
        this.direccion = direccion;
    }
    
    //setters and getters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    
    
    //metodos (crud para medicos)
    
    public boolean agregarMedico(Medico m){
        return this.medicos.add(m);
    }
    
    public Medico buscarMedico(int identificacion){
        for(Medico m : medicos){
            if(m.getIdentificacion()==identificacion)
                return m;
        }
        return null;
    }
    
    private int buscarIndiceMedico(int identificacion){
        for(int i=0; i < this.medicos.size();i++){
            Medico m = this.medicos.get(i);
            if(m.getIdentificacion()== identificacion){
                return i;
            }
        }
        return -1;
    }
    
    public boolean eliminarMedico(int identificacion){
        int index = this.buscarIndiceMedico(identificacion);
        if(index > 0){
            this.medicos.remove(index);
        }
        return false;
    }
    
    public boolean actualizarMedico(int identificacion, Medico medico){
        int index = this.buscarIndiceMedico(identificacion);
        if(index > 0){
            this.medicos.set(index, medico);
        }
        return false;
    }
    
    public ArrayList<Medico> obtenerMedicos(){
        return this.medicos;
    }
    
    //metodos (crud para pacientes)
    
    public boolean agregarPaciente(Paciente p){
        return this.pacientes.add(p);
    }
    
    public Paciente buscarPaciente(int cedula){
        for(Paciente p : pacientes){
            if(p.getCedula()==cedula){
            return p;
            }
        }
        return null;
    }
    
    private int buscarIndicePaciente(int cedula){
        for(int i=0; i<this.pacientes.size();i++){
            Paciente p = this.pacientes.get(i);
            if(p.getCedula()==cedula){
                return i ;
            }
        }
        return -1;
    }
    
    public boolean eliminarPaciente(int cedula){
        int index = this.buscarIndicePaciente(cedula);
        if(index > 0 ){
            this.pacientes.remove(index);
        }
        return false;
    }
    
    public boolean actualizarPaciente(int cedula, Paciente paciente){
        int index = this.buscarIndicePaciente(cedula);
        if(index > 0){
            this.pacientes.set(index, paciente);
        }
        return false;
    }
    
    public ArrayList<Paciente> obtenerPacientes(){
        return this.pacientes;
    }
    
    //metodos (crud para citas)
    
    public boolean agregarCita(Cita c){
        return this.citas.add(c);
    }
    
    public Cita buscarCita(int codigo){
        for(Cita c : citas){
            if(c.getCodigo()==codigo){
                return c;
            }
        }
        return null;
    }
    
    private int buscarIndiceCita(int codigo){
        for(int i=0; i < this.citas.size(); i++){
            Cita c = this.citas.get(i);
            if(c.getCodigo()==codigo){
                return i;
            }
        }
        return -1;
    }
    
    public boolean eliminarCita(int codigo){
        int index = this.buscarIndiceCita(codigo);
        if(index < 0){
            this.citas.remove(index);
        }
        return false;
    }
    
    public boolean actualizarCita(int codigo, Cita cita){
        int index = this.buscarIndiceCita(codigo);
        if(index < 0){
            this.citas.set(index, cita);
        }
        return false;
    }
    
    public ArrayList<Cita> obtenerCitas(){
        return this.citas;
    }
    
}
