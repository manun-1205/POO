/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.shospitalario.models;

/**
 *
 * @author Manuel
 */
 public class MedicamentoGenerico extends Medicamento {
    public MedicamentoGenerico(String nombre, String descripcion, double costo, double precioVenta) {
        super(nombre, descripcion, costo, precioVenta);
    }

    
}
