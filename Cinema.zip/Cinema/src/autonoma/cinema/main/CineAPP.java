
package autonoma.cinema.main;

import autonoma.cinema.models.Cine;
import autonoma.cinema.models.Pelicula;
import autonoma.cinema.views.VentanaPricipal;
import java.util.Date;

/**
 *
 * @author Manuel
 */
public class CineAPP {
    
    public static void main (String[] args){
        
//        Pelicula p1 = new Pelicula("Harry Poter", new Date(1990, 1, 1), "Fantasia");
//        Pelicula p2 = new Pelicula("Wolverine", new Date(1991, 2, 2), "Accion");
//        Pelicula p3 = new Pelicula("IronMan", new Date(1992, 3, 3), "Accion");
//        
//        System.out.println(p1);
//        System.out.println(p2);
//        System.out.println(p3);
        
        Cine cine = new Cine("cine Colombia", "fundadores", "3132345678" );
        
//        cine.agregarPelicula(p1);
//        cine.agregarPelicula(p2);
//        cine.agregarPelicula(p3);
//        
//        System.out.println(cine.buscarPelicula(4));
          
        VentanaPricipal ventana = new  VentanaPricipal(cine);
        ventana.setVisible(true);
    }
    
}
