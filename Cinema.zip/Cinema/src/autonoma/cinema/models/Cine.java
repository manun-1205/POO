
package autonoma.cinema.models;

import java.util.ArrayList;

/**
 *
 * @author Manuel
 */
public class Cine {
    //Atributos
    private String nombre;
    private String direccion;
    private String telefono;
    private Cartelera cartelera;
    
    //Constructor

    public Cine(String nombre, String direccion, String telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.cartelera = new Cartelera();
    }
    
    //metodos
    
    public boolean agregarPelicula(Pelicula p){
        return this.cartelera.agregarPelicula(p);
    }
    
    public Pelicula buscarPelicula(int codigo){
        return this.cartelera.buscarPelicula(codigo);
    }
    
    public Pelicula buscarPelicula(String nombre){
        return this.cartelera.buscarPelicula(nombre);
    }
    
    public boolean eliminarPelicula(int codigo){
        return this.cartelera.eliminarPelicula(codigo);
    }
    
    public boolean modificarPelicula(int codigo, Pelicula pelicula){
        return this.cartelera.modificarPelicula(codigo, pelicula);
    }
    
    public ArrayList<Pelicula> ObtenerPeliculas(){
        return this.cartelera.getPeliculas();
    }
    
}
