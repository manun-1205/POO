/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.juegopokemon.models;

/**
 *
 * @author Manuel
 */
public class Pikachu extends Pokemon implements PokemonElectrico{

    public Pikachu(int numPokedex, String nombre, Double peso, String temporada) {
        super(numPokedex, nombre, peso, temporada);
    }

    @Override
    public String atacarArañazo() {
        return "soy "+this.getNombre()+" y estoy lanzando un arañazo";
    }

    @Override
    public String atacarMordizco() {
        return "soy "+this.getNombre()+" y estoy lanzando un mordizco";
    }

    @Override
    public String atacatImpactoTrueno() {
        return "soy "+this.getNombre()+" y estoy lanzando un impacto trueno";
    }

    @Override
    public String atacarRayo() {
        return "soy "+this.getNombre()+" y estoy lanzando un rayo";
    }
    
    @Override
    public String punioTrueno() {
        return "soy "+this.getNombre()+" y estoy lanzando un piño de trueno";
    }

    @Override
    public String rayoCarga() {
        return "soy "+this.getNombre()+" y estoy lanzando un rayo carga";
    }
    
    public String saludar(){
        return "hola ! soy"+this.getNombre();
    }

    
    
}
