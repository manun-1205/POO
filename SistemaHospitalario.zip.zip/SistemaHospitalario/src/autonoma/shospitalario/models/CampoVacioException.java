/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.shospitalario.models;

/**
 *
 * @author Manuel
 */
public class CampoVacioException extends RuntimeException{
    
    
    public CampoVacioException(String mensaje) {
        super(mensaje);
    }
}


    

