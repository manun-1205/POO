
package autonoma.cinema.models;
import java.util.ArrayList;
/**
 *
 * @author Manuel
 */
public class Cartelera {
    
    //Atributos
    private ArrayList<Pelicula> peliculas;
    
    //constructores
    public Cartelera(){
        this.peliculas = new ArrayList();
    }
    
    //metodos
    public boolean agregarPelicula(Pelicula p){
        return this.peliculas.add(p);
    }
    
    public Pelicula buscarPelicula(int codigo){
        for(Pelicula p :peliculas){
            if(p.getCodigo()==codigo){
                return p;
            }
        }
        return null;
    }
    
    public Pelicula buscarPelicula(String nombre){
        for(Pelicula p :peliculas){
            if(p.getNombre().equals(nombre)){
                return p;
            }
        }
        return null;
    }
    
    private int buscarIndicePelicula(int codigo){
        for(int i=0; i<this.peliculas.size();i++){
            Pelicula p = this.peliculas.get(i);
            if(p.getCodigo()== codigo){
                return i;
            }
        }
        return -1;
    }
    
    public boolean eliminarPelicula(int codigo){
        int index = this.buscarIndicePelicula(codigo);
        if(index > 0 ){
            this.peliculas.remove(index);
        }
        return false;
    }
    
    public boolean modificarPelicula(int codigo, Pelicula pelicula){
        int index = this.buscarIndicePelicula(codigo);
        if(index > 0 ){
            this.peliculas.set(index, pelicula);
        }
        return false;
    }
    
    public ArrayList<Pelicula> getPeliculas(){
        return this.peliculas;
    }
}
