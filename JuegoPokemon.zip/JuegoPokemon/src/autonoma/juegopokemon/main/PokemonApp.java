/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package autonoma.juegopokemon.main;

import autonoma.juegopokemon.models.*;


/**
 *
 * @author Manuel
 */
public class PokemonApp {
    
    public static void main(String args[]){
    
    Pikachu pikachu =  new Pikachu(1, "Pika", 0.0, "T1");
    Pokemon pokemon = new Squirtle(1, "Squi", 0.0, "T1");
    PokemonFuego PokemonF = new Charmander(1, "Charma", 0.0, "T2");
    PokemonPlanta PokemonA = new Bulbasur(1, "bul", 0.0, "T3");
    
        System.out.println(pikachu.atacarArañazo());
        System.out.println(pokemon.atacarMordizco());
        System.out.println(PokemonF.atacarLanzallamas());
        System.out.println(PokemonA.atacarHojaAfilada());
        
        
        
    
       
    
}
}