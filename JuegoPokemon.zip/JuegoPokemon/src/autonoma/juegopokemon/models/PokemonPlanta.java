/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package autonoma.juegopokemon.models;

/**
 *
 * @author Manuel
 */
public interface PokemonPlanta {
    
    public abstract String atacatParalizar();
    public abstract String atacarDrenaje();
    public abstract String atacarHojaAfilada();
    public abstract String atacarLatigoCepta();
    
}
