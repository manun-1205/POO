
package autonoma.cinema.models;

import java.util.Date;

/**
 *
 * @author Manuel
 */
public class Pelicula {
    
    private static int autoIncrementar = 0;
    //Atributos
    private  String nombre;
    private int codigo;
    private String fechaLanzamiento;
    private String genero;
    
    //constructor

    public Pelicula(String nombre, String fechaLanzamiento, String genero) {
        Pelicula.autoIncrementar++;
        this.codigo=Pelicula.autoIncrementar;
        this.nombre = nombre;
        this.fechaLanzamiento = fechaLanzamiento;
        this.genero = genero;
    }
    
    //metodos de acceso

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getFechaLanzamiento() {
        return fechaLanzamiento;
    }

    public void setFechaLanzamiento(String fechaLanzamiento) {
        this.fechaLanzamiento = fechaLanzamiento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    //metodos
    
    @Override
    public String toString(){
        return "codigo : " + this.codigo + 
               ", nombre: " + this.nombre +
               ", fecha lanzamiento: " + this.fechaLanzamiento + 
               ", genero: " + this.genero;
    }
    
    
    
}
